package Algoritmos;

import Road_Accidents.MyArrayList;

public class HeapSort {

    public static void heapSort(MyArrayList<String[]> linkedListData, String caso) {
        int n = linkedListData.size();

        // Constrói o heap (rearranja o array)
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(linkedListData, n, i, caso);
        }

        // Extrai os elementos um a um do heap
        for (int i = n - 1; i > 0; i--) {
            String[] temp = linkedListData.get(0);
            linkedListData.set(0, linkedListData.get(i));
            linkedListData.set(i, temp);

            // Chama heapify na sub-árvore reduzida
            heapify(linkedListData, i, 0, caso);
        }
    }

    private static void heapify(MyArrayList<String[]> linkedListData, int n, int i, String caso) {
        int largestOrSmallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (caso.equals("piorCaso")) {
            if (left < n && linkedListData.get(left)[2].compareTo(linkedListData.get(largestOrSmallest)[2]) > 0) {
                largestOrSmallest = left;
            }
            if (right < n && linkedListData.get(right)[2].compareTo(linkedListData.get(largestOrSmallest)[2]) > 0) {
                largestOrSmallest = right;
            }
        } else {
            if (left < n && linkedListData.get(left)[2].compareTo(linkedListData.get(largestOrSmallest)[2]) < 0) {
                largestOrSmallest = left;
            }
            if (right < n && linkedListData.get(right)[2].compareTo(linkedListData.get(largestOrSmallest)[2]) < 0) {
                largestOrSmallest = right;
            }
        }

        if (largestOrSmallest != i) {
            String[] temp = linkedListData.get(i);
            linkedListData.set(i, linkedListData.get(largestOrSmallest));
            linkedListData.set(largestOrSmallest, temp);

            heapify(linkedListData, n, largestOrSmallest, caso);
        }
    }
}
