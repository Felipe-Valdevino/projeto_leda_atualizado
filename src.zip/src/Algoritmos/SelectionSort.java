package Algoritmos;

import Road_Accidents.MyArrayList;

public class SelectionSort {

    public static void selectionSort(MyArrayList<String[]> myArrayListData, String caso) {
        int n = myArrayListData.size();

        for (int i = 0; i < n - 1; i++) {
            int minOrMaxIdx = i;

            // Encontra o menor ou maior valor com base no caso
            for (int j = i + 1; j < n; j++) {
                if (caso.equals("piorCaso")) {
                    if (myArrayListData.get(j)[2].compareTo(myArrayListData.get(minOrMaxIdx)[2]) > 0) {
                        minOrMaxIdx = j;
                    }
                } else if (caso.equals("melhorCaso")) {
                    if (myArrayListData.get(j)[2].compareTo(myArrayListData.get(minOrMaxIdx)[2]) < 0) {
                        minOrMaxIdx = j;
                    }
                } else {
                    if (myArrayListData.get(j)[2].compareTo(myArrayListData.get(minOrMaxIdx)[2]) > 0) {
                        minOrMaxIdx = j;
                    }
                }
            }

            // Troca os elementos
            String[] temp = myArrayListData.get(minOrMaxIdx);
            myArrayListData.set(minOrMaxIdx, myArrayListData.get(i));
            myArrayListData.set(i, temp);
        }
    }
}
