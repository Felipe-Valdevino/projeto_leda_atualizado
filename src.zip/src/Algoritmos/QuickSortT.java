package Algoritmos;

import Road_Accidents.MyArrayList;

public class QuickSortT {

    public static void quickSort(MyArrayList<String[]> linkedListData, String caso, int index) {
        if (linkedListData == null || linkedListData.size() == 0) {
            throw new IllegalArgumentException("O MyArrayList não pode ser vazio ou nulo.");
        }
        quickSort(linkedListData, 0, linkedListData.size() - 1, caso, index);
    }

    private static void quickSort(MyArrayList<String[]> records, int low, int high, String caso, int index) {
        if (low < high) {
            int pivotIndex = partition(records, low, high, caso, index);
            quickSort(records, low, pivotIndex - 1, caso, index);
            quickSort(records, pivotIndex + 1, high, caso, index);
        }
    }

    private static int partition(MyArrayList<String[]> records, int low, int high, String caso, int index) {
        String[] pivot = records.get(high);  // Usando get() para acessar o elemento
        int i = low - 1;

        for (int j = low; j < high; j++) {
            boolean condition;
            switch (caso) {
                case "piorCaso":
                    condition = records.get(j)[index].compareTo(pivot[index]) > 0;
                    break;
                case "melhorCaso":
                    condition = records.get(j)[index].compareTo(pivot[index]) < 0;
                    break;
                default: // Caso médio ou padrão
                    condition = records.get(j)[index].compareTo(pivot[index]) <= 0;
                    break;
            }

            if (condition) {
                i++;
                swap(records, i, j);
            }
        }

        swap(records, i + 1, high);
        return i + 1;
    }

    private static void swap(MyArrayList<String[]> array, int i, int j) {
        String[] temp = array.get(i);
        array.set(i, array.get(j));  // Usando set() para substituir o valor
        array.set(j, temp);
    }
}
