package Algoritmos;

import Road_Accidents.MyArrayList;

public class HeapSortT {

    public static void heapSort(MyArrayList<String[]> list, String caso, int index) {
        int n = list.size();

        // Constrói o heap máximo
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(list, n, i, index);
        }

        // Extrai os elementos do heap um por um
        for (int i = n - 1; i > 0; i--) {
            // Move o maior elemento atual para o final da lista
            String[] temp = list.get(0);
            list.set(0, list.get(i));
            list.set(i, temp);

            // Chama o heapify no heap reduzido
            heapify(list, i, 0, index);
        }
    }

    private static void heapify(MyArrayList<String[]> list, int n, int i, int index) {
        int largest = i; // Inicializa o maior como raiz
        int left = 2 * i + 1; // Filho à esquerda
        int right = 2 * i + 2; // Filho à direita

        // Converte as datas para inteiros para comparação
        int largestValue = Integer.parseInt(list.get(largest)[index]);
        if (left < n) {
            int leftValue = Integer.parseInt(list.get(left)[index]);
            // Verifica se o filho à esquerda é maior que a raiz para ordenação decrescente
            if (leftValue > largestValue) {
                largest = left;
                largestValue = leftValue;
            }
        }

        if (right < n) {
            int rightValue = Integer.parseInt(list.get(right)[index]);
            // Verifica se o filho à direita é maior que o maior até agora para ordenação decrescente
            if (rightValue > largestValue) {
                largest = right;
            }
        }

        // Se o maior não for a raiz, troca os valores e continua o processo de heapificação
        if (largest != i) {
            String[] temp = list.get(i);
            list.set(i, list.get(largest));
            list.set(largest, temp);

            // Recursivamente faz heapify na subárvore afetada
            heapify(list, n, largest, index);
        }
    }
}
