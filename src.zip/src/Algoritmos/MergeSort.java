package Algoritmos;

import Road_Accidents.MyArrayList;

public class MergeSort {

    public static void mergeSort(MyArrayList<String[]> myArrayListData, String caso) {
        if (myArrayListData.size() < 2) return;
        int mid = myArrayListData.size() / 2;

        // Dividindo a lista em duas
        MyArrayList<String[]> left = new MyArrayList<>();
        MyArrayList<String[]> right = new MyArrayList<>();

        for (int i = 0; i < mid; i++) {
            left.add(myArrayListData.get(i));
        }
        for (int i = mid; i < myArrayListData.size(); i++) {
            right.add(myArrayListData.get(i));
        }

        // Recursivamente ordenando as duas metades
        mergeSort(left, caso);
        mergeSort(right, caso);

        // Unindo as duas metades ordenadas
        merge(myArrayListData, left, right, caso);
    }

    private static void merge(MyArrayList<String[]> myArrayListData, MyArrayList<String[]> left, MyArrayList<String[]> right, String caso) {
        int i = 0, j = 0, k = 0;

        // Mesclando os dois arrays ordenados
        while (i < left.size() && j < right.size()) {
            if (caso.equals("piorCaso") ? left.get(i)[2].compareTo(right.get(j)[2]) > 0 :
                caso.equals("melhorCaso") ? left.get(i)[2].compareTo(right.get(j)[2]) < 0 :
                left.get(i)[2].compareTo(right.get(j)[2]) > 0) {
                myArrayListData.set(k++, left.get(i++));
            } else {
                myArrayListData.set(k++, right.get(j++));
            }
        }

        // Copiando os elementos restantes de `left`, se houver
        while (i < left.size()) {
            myArrayListData.set(k++, left.get(i++));
        }

        // Copiando os elementos restantes de `right`, se houver
        while (j < right.size()) {
            myArrayListData.set(k++, right.get(j++));
        }
    }
}
