package Algoritmos;

import Road_Accidents.MyArrayList;

public class InsertionSortT {

    // Alterando o método para aceitar MyArrayList<String[]>
    public static void insertionSort(MyArrayList<String[]> linkedListData, String caso, int columnIndex) {
        int n = linkedListData.size(); // Usando size() de MyArrayList

        // Adapte o caso de ordenação para os diferentes cenários
        for (int i = 1; i < n; i++) {
            String[] key = linkedListData.get(i); // Usando get() de MyArrayList
            int j = i - 1;

            // Ordena em ordem decrescente pela coluna especificada
            while (j >= 0 && (caso.equals("piorCaso") ? key[columnIndex].compareTo(linkedListData.get(j)[columnIndex]) > 0 :
                    caso.equals("melhorCaso") ? key[columnIndex].compareTo(linkedListData.get(j)[columnIndex]) < 0 :
                    key[columnIndex].compareTo(linkedListData.get(j)[columnIndex]) > 0)) {
                linkedListData.set(j + 1, linkedListData.get(j)); // Usando set() para atualizar o valor
                j = j - 1;
            }
            linkedListData.set(j + 1, key); // Coloca o elemento ordenado na posição correta
        }
    }
}
