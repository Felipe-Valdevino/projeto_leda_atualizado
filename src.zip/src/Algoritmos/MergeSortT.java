package Algoritmos;

import Road_Accidents.MyArrayList;

public class MergeSortT {

    // Modificando para trabalhar com MyArrayList<String[]>
    public static void mergeSort(MyArrayList<String[]> linkedListData, String caso, int columnIndex) {
        if (linkedListData.size() < 2) {
            return;
        }

        // Divida a lista
        int mid = linkedListData.size() / 2;
        MyArrayList<String[]> left = new MyArrayList<>();
        MyArrayList<String[]> right = new MyArrayList<>();

        for (int i = 0; i < mid; i++) {
            left.add(linkedListData.get(i));
        }
        for (int i = mid; i < linkedListData.size(); i++) {
            right.add(linkedListData.get(i));
        }

        // Ordena as duas metades recursivamente
        mergeSort(left, caso, columnIndex);
        mergeSort(right, caso, columnIndex);

        // Mescla as duas metades
        merge(linkedListData, left, right, caso, columnIndex);
    }

    private static void merge(MyArrayList<String[]> linkedListData, MyArrayList<String[]> left, MyArrayList<String[]> right, String caso, int columnIndex) {
        int i = 0, j = 0, k = 0;

        while (i < left.size() && j < right.size()) {
            int compareResult = left.get(i)[columnIndex].compareTo(right.get(j)[columnIndex]);

            // Para piorCaso, melhorCaso, etc.
            if (caso.equals("piorCaso") ? compareResult > 0 : caso.equals("melhorCaso") ? compareResult < 0 : compareResult <= 0) {
                linkedListData.set(k++, left.get(i++));
            } else {
                linkedListData.set(k++, right.get(j++));
            }
        }

        // Adiciona o que sobrou de um dos lados
        while (i < left.size()) {
            linkedListData.set(k++, left.get(i++));
        }

        while (j < right.size()) {
            linkedListData.set(k++, right.get(j++));
        }
    }
}
