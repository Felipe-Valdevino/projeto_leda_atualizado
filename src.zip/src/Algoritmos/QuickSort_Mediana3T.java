package Algoritmos;

import Road_Accidents.MyArrayList;

public class QuickSort_Mediana3T {
    
    public static void quickSortMedianaDeTres(MyArrayList<String[]> records, String caso, int index) {
        if (records == null || records.size() == 0 || index < 0 || index >= records.get(0).length) {
            throw new IllegalArgumentException("Array vazio ou índice inválido.");
        }
        quickSort(records, 0, records.size() - 1, index);
    }

    private static void quickSort(MyArrayList<String[]> records, int low, int high, int index) {
        if (low < high) {
            int pivotIndex = partitionMedianaDeTres(records, low, high, index);
            quickSort(records, low, pivotIndex - 1, index);
            quickSort(records, pivotIndex + 1, high, index);
        }
    }

    private static int partitionMedianaDeTres(MyArrayList<String[]> records, int low, int high, int index) {
        int mid = low + (high - low) / 2;

        // Ordena low, mid e high para obter a mediana no índice `high`
        if (tryParseDouble(records.get(mid)[index]) < tryParseDouble(records.get(low)[index])) {
            swap(records, low, mid);
        }
        if (tryParseDouble(records.get(high)[index]) < tryParseDouble(records.get(low)[index])) {
            swap(records, low, high);
        }
        if (tryParseDouble(records.get(high)[index]) < tryParseDouble(records.get(mid)[index])) {
            swap(records, mid, high);
        }

        double pivotValue = tryParseDouble(records.get(high)[index]);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (tryParseDouble(records.get(j)[index]) <= pivotValue) {
                i++;
                swap(records, i, j);
            }
        }

        swap(records, i + 1, high);
        return i + 1;
    }

    private static double tryParseDouble(String str) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return Double.NaN; // Retorna NaN para indicar valor inválido
        }
    }

    private static void swap(MyArrayList<String[]> records, int i, int j) {
        String[] temp = records.get(i);
        records.set(i, records.get(j));
        records.set(j, temp);
    }
}
