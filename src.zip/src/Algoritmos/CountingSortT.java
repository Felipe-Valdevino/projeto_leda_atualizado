package Algoritmos;

import Road_Accidents.MyArrayList;

public class CountingSortT {

    // Modifique o método para aceitar MyArrayList
    public static void countingSort(MyArrayList<String[]> records, String caseType, int columnIndex) {
        int max = 10000;  // Ajuste conforme necessário
        int[] count = new int[max + 1];  // Array de contagem
        MyArrayList<String[]> output = new MyArrayList<>();  // Lista de saída

        // Contar a ocorrência de cada valor
        for (int i = 0; i < records.size(); i++) {  // Usa records.size() para acessar o tamanho da MyArrayList
            int value = Integer.parseInt(records.get(i)[columnIndex]);  // Acessa o valor da coluna especificada
            if (value > 0) {  // Ignora valores definidos como "0"
                count[value]++;
            }
        }

        // Modificar o array de contagem para que cada elemento armazene a soma acumulada
        for (int i = 1; i <= max; i++) {
            count[i] += count[i - 1];
        }

        // Construir o array de saída
        for (int i = records.size() - 1; i >= 0; i--) {  // Usa records.size() para acessar o tamanho da lista
            int value = Integer.parseInt(records.get(i)[columnIndex]);
            if (value > 0) {  // Ignora valores definidos como "0"
                output.add(records.get(i));  // Adiciona o item à lista de saída
                count[value]--;
            }
        }

        // Copiar a lista de saída de volta para a lista original
        for (int i = 0; i < output.size(); i++) {  // Usa output.size() para acessar o tamanho da lista
            records.set(i, output.get(i));  // Atualiza o elemento original com os valores ordenados
        }
    }
}
