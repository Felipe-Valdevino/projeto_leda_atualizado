package Algoritmos;

import Road_Accidents.MyArrayList;

public class QuickSort {

    public static void quickSort(MyArrayList<String[]> linkedListData, String caso) {
        if (linkedListData == null || linkedListData.size() == 0) {
            throw new IllegalArgumentException("A lista não pode ser vazia ou nula.");
        }
        quickSort(linkedListData, 0, linkedListData.size() - 1, caso);
    }

    private static void quickSort(MyArrayList<String[]> linkedListData, int low, int high, String caso) {
        if (low < high) {
            int pivotIndex = partition(linkedListData, low, high, caso);
            quickSort(linkedListData, low, pivotIndex - 1, caso);
            quickSort(linkedListData, pivotIndex + 1, high, caso);
        }
    }

    private static int partition(MyArrayList<String[]> linkedListData, int low, int high, String caso) {
        String[] pivot = linkedListData.get(high);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            boolean condition;
            switch (caso) {
                case "piorCaso":
                    condition = linkedListData.get(j)[2].compareTo(pivot[2]) > 0;
                    break;
                case "melhorCaso":
                    condition = linkedListData.get(j)[2].compareTo(pivot[2]) < 0;
                    break;
                default: // Caso médio ou padrão
                    condition = linkedListData.get(j)[2].compareTo(pivot[2]) <= 0;
                    break;
            }

            if (condition) {
                i++;
                swap(linkedListData, i, j);
            }
        }

        swap(linkedListData, i + 1, high);
        return i + 1;
    }

    private static void swap(MyArrayList<String[]> linkedListData, int i, int j) {
        String[] temp = linkedListData.get(i);
        linkedListData.set(i, linkedListData.get(j));
        linkedListData.set(j, temp);
    }
}
