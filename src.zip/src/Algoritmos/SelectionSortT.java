package Algoritmos;

import Road_Accidents.MyArrayList;

public class SelectionSortT {

    public static void selectionSort(MyArrayList<String[]> linkedListData, String caso, int columnIndex) {
        int n = linkedListData.size();

        for (int i = 0; i < n - 1; i++) {
            int minOrMaxIdx = i;

            // Encontra o menor ou maior valor com base no caso
            for (int j = i + 1; j < n; j++) {
                if (caso.equals("piorCaso")) {
                    if (linkedListData.get(j)[columnIndex].compareTo(linkedListData.get(minOrMaxIdx)[columnIndex]) > 0) {
                        minOrMaxIdx = j;
                    }
                } else if (caso.equals("melhorCaso")) {
                    if (linkedListData.get(j)[columnIndex].compareTo(linkedListData.get(minOrMaxIdx)[columnIndex]) < 0) {
                        minOrMaxIdx = j;
                    }
                } else {
                    if (linkedListData.get(j)[columnIndex].compareTo(linkedListData.get(minOrMaxIdx)[columnIndex]) > 0) {
                        minOrMaxIdx = j;
                    }
                }
            }

            // Troca os elementos
            String[] temp = linkedListData.get(minOrMaxIdx);
            linkedListData.set(minOrMaxIdx, linkedListData.get(i));
            linkedListData.set(i, temp);
        }
    }
}
