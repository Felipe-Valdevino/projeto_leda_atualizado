package Algoritmos;

import Road_Accidents.MyArrayList;

public class QuickSort_Mediana3 {

    public static void quickSortMedianaDeTres(MyArrayList<String[]> linkedListData, String caso, int index) {
        if (linkedListData == null || linkedListData.size() == 0 || index < 0 || index >= linkedListData.get(0).length) {
            throw new IllegalArgumentException("Array vazio ou índice inválido.");
        }
        quickSort(linkedListData, 0, linkedListData.size() - 1, index);
    }

    private static void quickSort(MyArrayList<String[]> linkedListData, int low, int high, int index) {
        if (low < high) {
            int pivotIndex = partitionMedianaDeTres(linkedListData, low, high, index);
            quickSort(linkedListData, low, pivotIndex - 1, index);
            quickSort(linkedListData, pivotIndex + 1, high, index);
        }
    }

    private static int partitionMedianaDeTres(MyArrayList<String[]> linkedListData, int low, int high, int index) {
        int mid = low + (high - low) / 2;

        // Ordena low, mid e high para obter a mediana no índice `high`
        if (tryParseDouble(linkedListData.get(mid)[index]) < tryParseDouble(linkedListData.get(low)[index])) {
            swap(linkedListData, low, mid);
        }
        if (tryParseDouble(linkedListData.get(high)[index]) < tryParseDouble(linkedListData.get(low)[index])) {
            swap(linkedListData, low, high);
        }
        if (tryParseDouble(linkedListData.get(high)[index]) < tryParseDouble(linkedListData.get(mid)[index])) {
            swap(linkedListData, mid, high);
        }

        double pivotValue = tryParseDouble(linkedListData.get(high)[index]);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (tryParseDouble(linkedListData.get(j)[index]) <= pivotValue) {
                i++;
                swap(linkedListData, i, j);
            }
        }

        swap(linkedListData, i + 1, high);
        return i + 1;
    }

    private static double tryParseDouble(String str) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return Double.NaN; // Retorna NaN para indicar valor inválido
        }
    }

    private static void swap(MyArrayList<String[]> linkedListData, int i, int j) {
        String[] temp = linkedListData.get(i);
        linkedListData.set(i, linkedListData.get(j));
        linkedListData.set(j, temp);
    }
}
