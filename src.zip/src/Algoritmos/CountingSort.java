package Algoritmos;

import Road_Accidents.MyArrayList;

public class CountingSort {
    public static void countingSort(MyArrayList<String[]> myArrayListData, String caso) {
        // Defina o máximo esperado (ajustar conforme necessário)
        int max = 10000; // Ajuste conforme a sua entrada de dados
        int[] count = new int[max + 1]; // Array de contagem
        MyArrayList<String[]> output = new MyArrayList<>(); // Array de saída

        // Preencher o array de saída com valores nulos para evitar erros de acesso
        for (int i = 0; i < myArrayListData.size(); i++) {
            output.add(null);
        }

        // Contar a ocorrência de cada valor
        for (int i = 0; i < myArrayListData.size(); i++) {
            try {
                // Converte o valor da coluna para double, depois arredonda para int
                double valueDouble = Double.parseDouble(myArrayListData.get(i)[3]);
                int value = (int) Math.round(valueDouble);

                // Incrementa o contador se o valor for válido
                if (value >= 0 && value <= max) {
                    count[value]++;
                }
            } catch (NumberFormatException e) {
                // Ignora valores inválidos
                System.out.println("Valor inválido encontrado na linha " + i + ": " + myArrayListData.get(i)[3]);
            }
        }

        // Modificar o array de contagem para armazenar a soma acumulativa
        for (int i = 1; i <= max; i++) {
            count[i] += count[i - 1];
        }

        // Construir o array de saída
        for (int i = myArrayListData.size() - 1; i >= 0; i--) {
            try {
                double valueDouble = Double.parseDouble(myArrayListData.get(i)[3]);
                int value = (int) Math.round(valueDouble);

                if (value >= 0 && value <= max) {
                    output.set(count[value] - 1, myArrayListData.get(i));
                    count[value]--;
                }
            } catch (NumberFormatException e) {
                // Ignora valores inválidos
            }
        }

        // Copiar o array de saída de volta para o array original
        for (int i = 0; i < myArrayListData.size(); i++) {
            myArrayListData.set(i, output.get(i));
        }
    }
}

