package Algoritmos;

import Road_Accidents.MyArrayList;

public class InsertionSort {

    public static void insertionSort(MyArrayList<String[]> myArrayListData, String caso) {
        int n = myArrayListData.size();

        // Adapte o caso de ordenação para os diferentes cenários
        for (int i = 1; i < n; i++) {
            String[] key = myArrayListData.get(i);
            int j = i - 1;

            // Ordena em ordem decrescente pela data (campo 2)
            while (j >= 0 && (caso.equals("piorCaso") ? key[2].compareTo(myArrayListData.get(j)[2]) > 0 :
                    caso.equals("melhorCaso") ? key[2].compareTo(myArrayListData.get(j)[2]) < 0 :
                    key[2].compareTo(myArrayListData.get(j)[2]) > 0)) {
                myArrayListData.set(j + 1, myArrayListData.get(j));
                j = j - 1;
            }
            myArrayListData.set(j + 1, key);
        }
    }
}
