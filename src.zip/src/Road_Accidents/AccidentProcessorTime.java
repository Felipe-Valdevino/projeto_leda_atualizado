package Road_Accidents;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Algoritmos.CountingSortT;
import Algoritmos.HeapSortT;
import Algoritmos.InsertionSortT;
import Algoritmos.MergeSortT;
import Algoritmos.QuickSortT;
import Algoritmos.QuickSort_Mediana3T;
import Algoritmos.SelectionSortT;

public class AccidentProcessorTime {

    // Método para ler o CSV e retornar uma MyArrayList<String[]>
    public static MyArrayList<String[]> readCsv(String filePath) {
        MyArrayList<String[]> records = new MyArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Ler os cabeçalhos
            line = br.readLine();
            records.add(line.split(",")); // Armazena o cabeçalho

            // Ler cada linha do arquivo
            while ((line = br.readLine()) != null) {
                records.add(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return records;
    }

    // Método para ordenar e salvar os registros com base no algoritmo e caso
    public static void sortAndSave(MyArrayList<String[]> records, String algorithm, String caseType) {
        // Copiar os registros para um novo array para ordenar (excluindo o cabeçalho)
        MyArrayList<String[]> recordsToSort = new MyArrayList<>();
        for (int i = 1; i < records.size(); i++) { // Começa em 1 para ignorar o cabeçalho
            recordsToSort.add(records.get(i));
        }

        // Verifica e converte a coluna "time" (coluna 3) para valores numéricos ou data
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        double minValue = Double.MAX_VALUE;
        double maxValue = Double.MIN_VALUE;

        for (int i = 0; i < recordsToSort.size(); i++) {
            String[] record = recordsToSort.get(i);
            String timeValue = record[3];
            try {
                if (timeValue != null && !timeValue.isEmpty()) {
                    if (timeValue.contains("-")) {
                        // Tenta converter valores no formato "yyyy-MM-dd" para um número
                        long timeInMillis = dateFormat.parse(timeValue).getTime(); // Converte para milissegundos desde 1970
                        record[3] = Double.toString(timeInMillis); // Converte para string numérica
                    } else if (timeValue.matches("\\d+\\.\\d+") || timeValue.matches("\\d+")) {
                        // Se o valor for numérico (decimal ou inteiro), trate-o como hora decimal
                    } else if (timeValue.contains(":")) {
                        // Trata valores no formato "hh:mm"
                        String[] timeParts = timeValue.split(":");
                        double hours = Double.parseDouble(timeParts[0]);
                        double minutes = Double.parseDouble(timeParts[1]) / 60.0;
                        record[3] = Double.toString(hours + minutes); // Converte para horas decimais
                    } else {
                        // Tenta converter diretamente para Double
                        Double.parseDouble(timeValue); // Valida o valor
                    }
                } else {
                    record[3] = "0.0"; // Substitui valores vazios por "0.0"
                }
            } catch (NumberFormatException | ParseException e) {
                System.out.println("Valor inválido na linha " + (i + 2) + ": " + timeValue);
                record[3] = "0.0"; // Substitui valores inválidos por "0.0"
            }

            // Conversão para encontrar min e max valores
            try {
                double currentValue = Double.parseDouble(record[3]);
                minValue = Math.min(minValue, currentValue);
                maxValue = Math.max(maxValue, currentValue);
            } catch (NumberFormatException e) {
                System.out.println("Erro na conversão para encontrar min/max na linha " + (i + 2) + ": " + record[3]);
            }
        }

        // Conversão para inteiros antes de usar o CountingSort
        for (int i = 0; i < recordsToSort.size(); i++) {
            String[] record = recordsToSort.get(i);
            try {
                double value = Double.parseDouble(record[3]);
                if (value < 0) {
                    System.out.println("Valor negativo encontrado na linha " + (i + 2) + ": " + value);
                    record[3] = "0"; // Define para 0 se o valor for negativo
                } else {
                    record[3] = Integer.toString((int) value); // Converte para inteiro
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro na conversão para inteiro na linha " + (i + 2) + ": " + record[3]);
                record[3] = "0"; // Valores inválidos convertidos para 0
            }
        }

        // Verifica se os valores min e max são válidos
        if (minValue < 0 || maxValue < 0) {
            System.out.println("Valores inválidos encontrados: min = " + minValue + ", max = " + maxValue);
            return; // Evita chamar o Counting Sort se os valores não forem válidos
        }

        long startTime = System.currentTimeMillis();

        // Seleciona e executa o algoritmo de ordenação
        switch (algorithm) {
            case "insertionSort":
                InsertionSortT.insertionSort(recordsToSort, caseType, 3); // Ordena pela coluna "time"
                break;
            case "selectionSort":
                SelectionSortT.selectionSort(recordsToSort, caseType, 3);
                break;
            case "mergeSort":
                MergeSortT.mergeSort(recordsToSort, caseType, 3);
                break;
            case "quickSort":
                QuickSortT.quickSort(recordsToSort, caseType, 3);
                break;
            case "quickSortMedianaDeTres":
                QuickSort_Mediana3T.quickSortMedianaDeTres(recordsToSort, caseType, 3);
                break;
            case "countingSort":
                // Verifica o range antes de chamar o CountingSort
                if (maxValue >= 0 && maxValue < Integer.MAX_VALUE) {
                    CountingSortT.countingSort(recordsToSort, caseType, 3);
                } else {
                    System.out.println("Erro: Range inválido para Counting Sort.");
                }
                break;
            case "heapSort":
                HeapSortT.heapSort(recordsToSort, caseType, 3);
                break;
            default:
                throw new IllegalArgumentException("Algoritmo desconhecido: " + algorithm);
        }

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        // Criação do diretório se não existir
        File directory = new File("./util");
        if (!directory.exists()) {
            directory.mkdirs(); // Cria o diretório se não existir
        }

        // Grava o resultado em um arquivo CSV
        String outputFilePath = "./util/accidents_NCBMV_time_" + algorithm + "_" + caseType + ".csv";
        writeCsv(recordsToSort, outputFilePath);

        // Adiciona o tempo de execução a um arquivo separado
        appendExecutionTime(algorithm, caseType, executionTime);
    }

    public static void writeCsv(MyArrayList<String[]> records, String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < records.size(); i++) {
                String[] record = records.get(i);
                if (record != null) { // Verifica se o registro não é nulo
                    bw.write(String.join(",", record));
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void appendExecutionTime(String algorithm, String caseType, long time) {
        String outputFilePath = "./util/execution_times_time.csv";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath, true))) {
            bw.write(algorithm + "," + caseType + "," + time + "ms");
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
