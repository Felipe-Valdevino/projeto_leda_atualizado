package Road_Accidents;

import java.io.*;
import java.text.SimpleDateFormat;

import Algoritmos.CountingSort;
import Algoritmos.HeapSort;
import Algoritmos.InsertionSort;
import Algoritmos.MergeSort;
import Algoritmos.QuickSort;
import Algoritmos.QuickSort_Mediana3;
import Algoritmos.SelectionSort;

public class AccidentProcessorData {

    // Método para ler o CSV e retornar uma MyArrayList<String[]>
    public static MyArrayList<String[]> readCsv(String filePath) {
        MyArrayList<String[]> records = new MyArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine(); // Ignora o cabeçalho

            while ((line = br.readLine()) != null) {
                records.add(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return records;
    }

    // Método para ordenar e salvar os dados
    public static void sortAndSave(MyArrayList<String[]> myArrayListData, String algorithm, String caseType) {
        // Definindo a coluna para ordenação (por padrão "time" na posição 3)
        int sortColumnIndex = 3;

        // Gerar caso médio
        if ("medio".equalsIgnoreCase(caseType)) {
            generatePartialOrder(myArrayListData, sortColumnIndex);
        }

        // Normalizar valores para CountingSort
        if ("countingSort".equals(algorithm)) {
            normalizeColumnForCountingSort(myArrayListData, sortColumnIndex);
        }

        // Converter valores de "time" para números válidos
        for (int i = 0; i < myArrayListData.size(); i++) {
            String[] record = myArrayListData.get(i);
            String timeValue = record[sortColumnIndex];
            if (timeValue != null && !timeValue.isEmpty()) {
                try {
                    if (timeValue.contains("-")) {
                        long timeInMillis = new SimpleDateFormat("yyyy-MM-dd").parse(timeValue).getTime();
                        record[sortColumnIndex] = String.valueOf(timeInMillis);
                    } else {
                        record[sortColumnIndex] = String.valueOf(Double.parseDouble(timeValue));
                    }
                } catch (Exception e) {
                    record[sortColumnIndex] = "0.0"; // Valor padrão para erros
                }
            }
        }

        // Criar diretório se não existir
        File directory = new File("./util");
        if (!directory.exists()) {
            directory.mkdirs(); // Cria o diretório se não existir
        }

        long startTime = System.currentTimeMillis();

        // Executa o algoritmo de ordenação
        switch (algorithm) {
            case "insertionSort" -> InsertionSort.insertionSort(myArrayListData, caseType);
            case "selectionSort" -> SelectionSort.selectionSort(myArrayListData, caseType);
            case "mergeSort" -> MergeSort.mergeSort(myArrayListData, caseType);
            case "quickSort" -> QuickSort.quickSort(myArrayListData, caseType);
            case "quickSortMedianaDeTres" -> QuickSort_Mediana3.quickSortMedianaDeTres(myArrayListData, caseType, sortColumnIndex);
            case "countingSort" -> CountingSort.countingSort(myArrayListData, caseType);
            case "heapSort" -> HeapSort.heapSort(myArrayListData, caseType);
            default -> throw new IllegalArgumentException("Algoritmo desconhecido: " + algorithm);
        }

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        // Salva os resultados ordenados
        String outputFilePath = "./util/accidents_NCBMV_date_" + algorithm + "_" + caseType + ".csv";
        writeCsv(myArrayListData, outputFilePath);

        appendExecutionTime(algorithm, caseType, executionTime);
    }

    private static void generatePartialOrder(MyArrayList<String[]> records, int columnIndex) {
        int partitionSize = records.size() / 2;
        for (int i = 1; i < partitionSize; i++) {
            for (int j = i + 1; j < partitionSize; j++) {
                if (records.get(i)[columnIndex].compareTo(records.get(j)[columnIndex]) > 0) {
                    String[] temp = records.get(i);
                    records.set(i, records.get(j));
                    records.set(j, temp);
                }
            }
        }
    }

    private static void normalizeColumnForCountingSort(MyArrayList<String[]> records, int columnIndex) {
        for (int i = 1; i < records.size(); i++) {
            try {
                Integer.parseInt(records.get(i)[columnIndex].trim());
            } catch (NumberFormatException e) {
                records.get(i)[columnIndex] = "0";
            }
        }
    }

    public static void writeCsv(MyArrayList<String[]> records, String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < records.size(); i++) {
                String[] record = records.get(i);
                if (record != null) {
                    bw.write(String.join(",", record));
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void appendExecutionTime(String algorithm, String caseType, long time) {
        String outputFilePath = "./util/execution_timesData.csv";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath, true))) {
            bw.write(algorithm + "," + caseType + "," + time + "ms");
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

