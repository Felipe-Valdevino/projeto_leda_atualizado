package Road_Accidents;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ProcessFiles {

    /**
     * Processa arquivos .txt em um diretório, convertendo os valores em arrays de double.
     *
     * directoryPath Caminho do diretório a ser processado.
     * Uma lista de arrays de double, onde cada array representa os valores de um arquivo.
     */
    public static ArrayList<double[]> processFiles(String directoryPath) {
        File directory = new File(directoryPath);
        ArrayList<double[]> vectors = new ArrayList<>();

        // Verifica se o caminho é válido
        if (!directory.isDirectory()) {
            System.err.println("O caminho especificado não é um diretório: " + directoryPath);
            return vectors;
        }

        // Filtra arquivos .txt no diretório
        File[] files = directory.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
        if (files == null || files.length == 0) {
            System.err.println("Nenhum arquivo .txt encontrado no diretório: " + directoryPath);
            return vectors;
        }

        // Processa cada arquivo
        for (File file : files) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                ArrayList<Double> values = new ArrayList<>();
                String line;

                // Lê cada linha do arquivo
                while ((line = reader.readLine()) != null) {
                    try {
                        double value = Double.parseDouble(line.trim());
                        values.add(value);
                    } catch (NumberFormatException e) {
                        System.err.println("Valor inválido no arquivo " + file.getName() + ": " + line);
                    }
                }

                // Converte a lista de valores para um array de double
                double[] doubleArray = new double[values.size()];
                for (int i = 0; i < values.size(); i++) {
                    doubleArray[i] = values.get(i);
                }
                vectors.add(doubleArray);

            } catch (IOException e) {
                System.err.println("Erro ao ler o arquivo " + file.getName() + ": " + e.getMessage());
            }
        }

        return vectors;
    }
}
