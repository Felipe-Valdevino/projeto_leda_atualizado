package Road_Accidents;

import java.util.Arrays;

public class MyArrayList<T> {
    private Object[] array;
    private int size;

    public MyArrayList() {
        array = new Object[10]; // Tamanho inicial
        size = 0;
    }

    public void add(T element) {
        if (size == array.length) {
            array = Arrays.copyOf(array, array.length * 2); // Dobra o tamanho do array
        }
        array[size++] = element;
    }

    public T get(int index) {
        if (index >= size) {
            throw new IndexOutOfBoundsException();
        }
        return (T) array[index];
    }

    public void set(int index, T element) {
        if (index >= size) {
            throw new IndexOutOfBoundsException();
        }
        array[index] = element;
    }

    public int size() {
        return size;
    }

    public void shuffle() {
        for (int i = size - 1; i > 0; i--) {
            int j = (int) (Math.random() * (i + 1));
            T temp = (T) array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    public void reverse() {
        for (int i = 0; i < size / 2; i++) {
            T temp = (T) array[i];
            array[i] = array[size - i - 1];
            array[size - i - 1] = temp;
        }
    }
}
