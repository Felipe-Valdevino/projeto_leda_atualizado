package Road_Accidents;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        // Caminhos para arquivos CSV
        String arquivoEntrada = "./util/road_accidents_czechia_2016_2022.csv";
        String arquivoEntrada2 = "./util/pedestrian.csv";

        // Caminhos para os arquivos de saída
        String arquivoSaidaAlcool = "./util/alcohol_accidents.csv";
        String arquivoSaidaNCBMV = "./util/accidents_NCBMV.csv";
        String arquivoSaidaCWFA = "./util/accidents_CWFA.csv";
        String arquivoSaidaDrunk = "./util/drunk_pedestrians.csv";

        // Filtrar acidentes com álcool
        MyArrayList<String[]> acidentesComAlcool = AccidentFilter.filtrarAcidentesPorAlcool(arquivoEntrada);
        AccidentFilter.salvarRegistrosEmArquivo(acidentesComAlcool, arquivoSaidaAlcool);

        // Filtrar acidentes sem colisão de veículos em movimento
        MyArrayList<String[]> acidentesSemColisao = AccidentFilter.filtrarAcidentesSemColisaoDeVeiculos(arquivoEntrada);
        AccidentFilter.salvarRegistrosEmArquivo(acidentesSemColisao, arquivoSaidaNCBMV);

        // Filtrar acidentes causados por animais da floresta
        MyArrayList<String[]> acidentesAnimaisFloresta = AccidentFilter.filtrarAcidentesPorAnimaisDaFloresta(arquivoSaidaNCBMV);
        AccidentFilter.salvarRegistrosEmArquivo(acidentesAnimaisFloresta, arquivoSaidaCWFA);

        // Filtrar pedestres que estavam sob a influência de álcool
        MyArrayList<String[]> pedestresSobAlcool = AccidentFilter.filtrarPedestresSobAlcool(arquivoEntrada2);
        AccidentFilter.salvarRegistrosEmArquivo(pedestresSobAlcool, arquivoSaidaDrunk);

        // Caminho para o arquivo CSV de acidentes (filtrado)
        String csvFilePath = "./util/accidents_NCBMV.csv"; // Arquivo de entrada para processamento

        // Leia o arquivo CSV
        MyArrayList<String[]> records1 = AccidentProcessorData.readCsv(csvFilePath);

        if (records1 == null || records1.size() == 0) {
            System.out.println("Arquivo CSV vazio ou inválido.");
            return;
        }

        // Algoritmos e casos para teste
        String[] algorithms = {"insertionSort", "selectionSort", "mergeSort", "quickSort", "countingSort", "heapSort"};
        String[] cases = {"melhorCaso", "medioCaso", "piorCaso"};

        // Para cada algoritmo e caso, execute a ordenação e salve os resultados
        for (String algorithm : algorithms) {
            for (String caso : cases) {
                System.out.println("Executando " + algorithm + " no " + caso + " para Data");

                // Modificar os dados conforme o caso
                if ("medioCaso".equals(caso)) {
                    // Embaralha os registros para o caso médio
                    records1.shuffle();
                } else if ("piorCaso".equals(caso)) {
                    // Inverte a ordem dos registros para o pior caso
                    records1.reverse();
                }

                // Ordenar e salvar os resultados
                AccidentProcessorData.sortAndSave(records1, algorithm, caso);
            }
        }

        // Agora, processe e ordene os dados pelo tempo
        MyArrayList<String[]> records2 = AccidentProcessorTime.readCsv(csvFilePath);

        if (records2 == null || records2.size() == 0) {
            System.out.println("Arquivo CSV vazio ou inválido.");
            return;
        }

        for (String algorithm : algorithms) {
            for (String caso : cases) {
                System.out.println("Executando " + algorithm + " no " + caso + " para tempo");
                AccidentProcessorTime.sortAndSave(records2, algorithm, caso);
            }
        }

        System.out.println("Processamento e ordenação por data e tempo concluídos.");
    }
}
