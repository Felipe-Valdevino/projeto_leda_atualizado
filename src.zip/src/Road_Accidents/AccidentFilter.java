package Road_Accidents;

import java.io.*;
import Road_Accidents.MyArrayList;

public class AccidentFilter {

    // Método para filtrar acidentes com álcool e retornar uma MyArrayList
    public static MyArrayList<String[]> filtrarAcidentesPorAlcool(String arquivoEntrada) {
        MyArrayList<String[]> registrosFiltrados = new MyArrayList<>();
        String linha;
        String separador = ","; // Separador usado no CSV

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            // Lê a primeira linha que contém o cabeçalho
            String cabecalho = br.readLine();
            if (cabecalho != null) {
                registrosFiltrados.add(cabecalho.split(separador)); // Armazena o cabeçalho
            }

            // Lê e processa cada linha do arquivo
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(separador);

                // Verifica se a coluna 'alcohol' (índice 9) tem o valor "ne"
                if (dados.length > 9 && "ne".equals(dados[9])) {
                    registrosFiltrados.add(dados); // Adiciona os registros filtrados
                }
            }

            System.out.println("Acidentes com álcool filtrados com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return registrosFiltrados;
    }

    // Método para filtrar acidentes sem colisão de veículos em movimento e retornar uma MyArrayList
    public static MyArrayList<String[]> filtrarAcidentesSemColisaoDeVeiculos(String arquivoEntrada) {
        MyArrayList<String[]> registrosFiltrados = new MyArrayList<>();
        String linha;
        String separador = ","; // Separador usado no CSV

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            // Lê a primeira linha que contém o cabeçalho
            String cabecalho = br.readLine();
            if (cabecalho != null) {
                registrosFiltrados.add(cabecalho.split(separador)); // Armazena o cabeçalho
            }

            // Lê e processa cada linha do arquivo
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(separador);

                // Verifica se a coluna 'crash_kind' (índice 6) tem o valor esperado
                if (dados.length > 6 && "not an option It is not a collision between moving vehicles".equals(dados[6])) {
                    registrosFiltrados.add(dados); // Adiciona os registros filtrados
                }
            }

            System.out.println("Acidentes sem colisão de veículos filtrados com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return registrosFiltrados;
    }

    // Método para filtrar acidentes causados por animais da floresta e retornar uma MyArrayList
    public static MyArrayList<String[]> filtrarAcidentesPorAnimaisDaFloresta(String arquivoEntrada) {
        MyArrayList<String[]> registrosFiltrados = new MyArrayList<>();
        String linha;
        String separador = ","; // Separador usado no CSV

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            // Lê a primeira linha que contém o cabeçalho
            String cabecalho = br.readLine();
            if (cabecalho != null) {
                registrosFiltrados.add(cabecalho.split(separador)); // Armazena o cabeçalho
            }

            // Lê e processa cada linha do arquivo
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(separador);

                // Verifica se a coluna 'accident_kind' (índice 5) tem o valor esperado
                if (dados.length > 5 && "collision with forest animals".equals(dados[5])) {
                    registrosFiltrados.add(dados); // Adiciona os registros filtrados
                }
            }

            System.out.println("Acidentes causados por animais da floresta filtrados com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return registrosFiltrados;
    }

    // Método para filtrar pedestres que estavam sob a influência de álcool e retornar uma MyArrayList
    public static MyArrayList<String[]> filtrarPedestresSobAlcool(String arquivoEntrada) {
        MyArrayList<String[]> registrosFiltrados = new MyArrayList<>();
        String linha;
        String separador = ","; // Separador usado no CSV

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            // Lê a primeira linha que contém o cabeçalho
            String cabecalho = br.readLine();
            if (cabecalho != null) {
                registrosFiltrados.add(cabecalho.split(separador)); // Armazena o cabeçalho
            }

            // Lê e processa cada linha do arquivo
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(separador);

                // Verifica se a coluna 'pedestrian_condition' (índice 4) contém "under the influence of alcohol"
                if (dados.length > 3 && dados[3].trim().startsWith("under the influence of alcohol")) {
                    registrosFiltrados.add(dados); // Adiciona os registros filtrados
                }
            }

            System.out.println("Pedestres sob influência de álcool filtrados com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return registrosFiltrados;
    }

    // Método para salvar os registros filtrados em um arquivo CSV
    public static void salvarRegistrosEmArquivo(MyArrayList<String[]> registros, String arquivoSaida) {
        File arquivo = new File(arquivoSaida);
        // Cria o diretório se não existir
        arquivo.getParentFile().mkdirs();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo))) {
            for (int i = 0; i < registros.size(); i++) {
                String[] record = registros.get(i);
                bw.write(String.join(",", record));
                bw.newLine();
            }

            System.out.println("Arquivo " + arquivoSaida + " gerado com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
